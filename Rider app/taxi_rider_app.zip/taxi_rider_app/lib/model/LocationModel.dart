import 'package:google_maps_flutter/google_maps_flutter.dart';

class LocationModel {
  String? address;
  LatLng? sourceLocation;

  LocationModel({this.address, this.sourceLocation});
}
