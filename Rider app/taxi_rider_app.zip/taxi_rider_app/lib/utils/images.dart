const ic_app_logo = 'images/ic_app_logo.jpg';

const DriverIcon = 'images/ic_car.png';
const SourceIcon = 'images/ic_source_pin.png';
const DestinationIcon = 'images/ic_des_pin.png';
const paymentSuccessful = "images/payment_successful.json";
const MultipleDriver = 'images/ic_car.png';

const ic_mobile = 'images/ic_mobile.png';
const ic_logout = 'images/ic_logout.png';

const ic_google = 'images/ic_google.png';
const ic_apple = "images/ic_apple.png";
const ic_add_user = 'images/ic_add_user.png';
const ic_insta = 'images/ic_insta.png';
const ic_twitter = 'images/ic_twitter.png';
const ic_linked = 'images/ic_linked.png';
const ic_facebook = 'images/ic_facebook.png';
const ic_walk1 = 'images/ic_walk1.jpg';
const ic_walk2 = 'images/ic_walk2.jpg';
const ic_walk3 = 'images/ic_walk3.jpg';
const ic_my_rides = 'images/ic_my_rides.png';
const ic_logo_white = 'images/ic_logo_white.png';
const ic_my_profile = 'images/ic_my_profile.png';
const ic_my_wallet = 'images/my_wallet.png';
const ic_update_bank_info = "images/ic_update_bank_info.png";
const ic_emergency_contact = 'images/ic_emergency_contact.png';
const ic_setting = 'images/ic_setting.png';
const ic_history_img1 = 'images/icons/ic_new_ride_requested.png';
const ic_history_img2 = 'images/icons/ic_accepted.png';
const ic_history_img3 = 'images/icons/ic_arriving.png';
const ic_history_img4 = 'images/icons/ic_arrived.png';
const ic_history_img5 = 'images/icons/in_progress.png';
const ic_history_img6 = 'images/icons/ic_canceled.png';
const ic_history_img7 = 'images/icons/ic_completed.png';
const ic_gallery = "images/ic_gallery.png";
const ic_camera = "images/ic_camera.png";


const ic_us='images/flag/ic_us.png';
const ic_india='images/flag/ic_india.png';
const ic_ar='images/flag/ic_ar.png';
const ic_spain='images/flag/ic_spain.png';
const ic_south_africa='images/flag/ic_south_africa.png';
const ic_france='images/flag/ic_france.png';
const ic_germany='images/flag/ic_germany.png';
const ic_indonesia='images/flag/ic_indonesia.png';
const ic_portugal='images/flag/ic_portugal.png';
const ic_turkey='images/flag/ic_turkey.png';
const ic_vitnam='images/flag/ic_vitnam.png';
const ic_dutch='images/flag/ic_dutch.png';
const ic_russia='images/flag/ic_russia.png';
const ic_pakistan='images/flag/ic_pakistan.png';
const ic_armenia='images/flag/ic_armenia.png';
const ic_china='images/flag/ic_china.png';
const ic_bangladesh='images/flag/ic_bangladesh.png';
const ic_japan='images/flag/ic_japan.png';
const ic_korea='images/flag/ic_korea.png';